package com.dev.focusgram;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.method.LinkMovementMethod;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(48, 48, 48, 32);

        TextView title = new TextView(this);
        title.setText("FocusGram");
        title.setTextSize(30);
        title.setTextColor(0xFF111111);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView info = new TextView(this);
        info.setText(
            "A focus layer for the official Instagram app.\\n\\n" +
            "Instagram remains installed and supplies the actual posts, messages, Stories and Reels.\\n\\n" +
            "Enable FocusGram under Android Accessibility settings. The service is intentionally limited to Instagram's package."
        );
        info.setTextSize(16);
        info.setPadding(0, 40, 0, 40);
        root.addView(info, new LinearLayout.LayoutParams(-1, 0, 1));

        Button settings = new Button(this);
        settings.setText("Enable FocusGram Accessibility");
        settings.setOnClickListener(v ->
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        );
        root.addView(settings, new LinearLayout.LayoutParams(-1, -2));

        setContentView(root);
    }
}
