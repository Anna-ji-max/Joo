package com.dev.focusgram;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Focus layer for the official Instagram app.
 *
 * Important:
 * - This service does not log in to Instagram.
 * - It does not read private network traffic or call private Instagram APIs.
 * - It only reacts to Android accessibility information made available by the OS.
 *
 * Instagram's package name is deliberately isolated in one constant.
 */
public class InstagramFocusService extends AccessibilityService {

    private static final String INSTAGRAM_PACKAGE = "com.instagram.android";

    private final Handler main = new Handler(Looper.getMainLooper());

    private WindowManager wm;
    private FrameLayout overlay;
    private WindowManager.LayoutParams overlayParams;

    private boolean instagramForeground = false;
    private ScreenState state = ScreenState.UNKNOWN;
    private long lastUiChange = 0L;

    private enum ScreenState {
        UNKNOWN,
        HOME,
        STORIES,
        PROFILE,
        REELS,
        EXPLORE,
        BLOCKED
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();

        AccessibilityServiceInfo info = getServiceInfo();
        info.packageNames = new String[]{INSTAGRAM_PACKAGE};
        info.eventTypes =
                AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED |
                AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED |
                AccessibilityEvent.TYPE_VIEW_CLICKED |
                AccessibilityEvent.TYPE_VIEW_SCROLLED |
                AccessibilityEvent.TYPE_VIEW_SELECTED;
        info.notificationTimeout = 30;
        info.flags |= AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS;
        info.flags |= AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
        setServiceInfo(info);

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        CharSequence pkg = event.getPackageName();
        if (pkg == null || !INSTAGRAM_PACKAGE.contentEquals(pkg)) {
            return;
        }

        instagramForeground = true;
        lastUiChange = System.nanoTime();

        // Keep analysis lightweight: only inspect text/content descriptions from
        // the current accessibility tree, not screenshots or network traffic.
        ScreenState detected = detectScreen(getRootInActiveWindow());

        if (detected != ScreenState.UNKNOWN && detected != state) {
            state = detected;
            applyState(detected);
        }

        // If Instagram reports a scroll while on a blocked surface, keep the
        // blocking surface present. We intentionally do not fabricate Instagram data.
        if (event.getEventType() == AccessibilityEvent.TYPE_VIEW_SCROLLED) {
            if (state == ScreenState.REELS || state == ScreenState.EXPLORE || state == ScreenState.PROFILE) {
                showBlocker(blockTitle(state), blockMessage(state));
            }
        }
    }

    @Override
    public void onInterrupt() {
        removeOverlay();
        instagramForeground = false;
    }

    private ScreenState detectScreen(AccessibilityNodeInfo root) {
        if (root == null) return ScreenState.UNKNOWN;

        String text = collectText(root).toLowerCase(Locale.ROOT);

        // These are deliberately broad signals. Instagram's UI can change,
        // so the detector never assumes one fixed coordinate layout.
        if (containsAny(text, "reels", "reel")) {
            // Reels can also appear in home content. Prefer explicit bottom
            // navigation signals only when available.
            if (containsAny(text, "reels tab", "reels selected")) {
                return ScreenState.REELS;
            }
        }

        if (containsAny(text, "explore", "search")) {
            if (containsAny(text, "search selected", "explore selected")) {
                return ScreenState.EXPLORE;
            }
        }

        if (containsAny(text, "story", "stories")) {
            if (containsAny(text, "your story", "add to story", "stories")) {
                return ScreenState.STORIES;
            }
        }

        if (containsAny(text, "profile", "edit profile", "followers", "following")) {
            return ScreenState.PROFILE;
        }

        // Default Instagram surface.
        return ScreenState.HOME;
    }

    private String collectText(AccessibilityNodeInfo node) {
        StringBuilder out = new StringBuilder(1024);
        collect(node, out, 0);
        return out.toString();
    }

    private void collect(AccessibilityNodeInfo node, StringBuilder out, int depth) {
        if (node == null || depth > 20) return;

        CharSequence text = node.getText();
        CharSequence desc = node.getContentDescription();

        if (text != null) {
            out.append(' ').append(text);
        }
        if (desc != null) {
            out.append(' ').append(desc);
        }

        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                collect(child, out, depth + 1);
                child.recycle();
            }
        }
    }

    private boolean containsAny(String text, String... values) {
        for (String v : values) {
            if (text.contains(v)) return true;
        }
        return false;
    }

    private void applyState(ScreenState newState) {
        if (!instagramForeground) {
            removeOverlay();
            return;
        }

        if (newState == ScreenState.REELS || newState == ScreenState.EXPLORE) {
            showBlocker(blockTitle(newState), blockMessage(newState));
        } else if (newState == ScreenState.PROFILE) {
            showProfileMask();
        } else {
            removeOverlay();
        }
    }

    private String blockTitle(ScreenState s) {
        return s == ScreenState.REELS ? "Reels are locked" : "Explore is locked";
    }

    private String blockMessage(ScreenState s) {
        return s == ScreenState.REELS
                ? "Protect your attention. Come back to your friends instead."
                : "You do not need an endless discovery feed.";
    }

    /**
     * A content-region overlay. It deliberately leaves a bottom strip untouched
     * so Instagram's bottom navigation remains visible.
     */
    private void showBlocker(String title, String message) {
        if (wm == null) return;

        if (overlay == null) createOverlay();

        overlay.removeAllViews();
        overlay.setBackgroundColor(Color.rgb(7, 7, 10));

        FrameLayout inner = new FrameLayout(this);

        TextView t = label(title, 28, Color.WHITE);
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-1, -2);
        tp.gravity = Gravity.CENTER_HORIZONTAL;
        tp.topMargin = dp(190);
        tp.leftMargin = dp(24);
        tp.rightMargin = dp(24);
        inner.addView(t, tp);

        TextView m = label("“" + message + "”", 18, Color.rgb(185,185,195));
        FrameLayout.LayoutParams mp = new FrameLayout.LayoutParams(-1, -2);
        mp.gravity = Gravity.CENTER_HORIZONTAL;
        mp.topMargin = dp(250);
        mp.leftMargin = dp(34);
        mp.rightMargin = dp(34);
        inner.addView(m, mp);

        Button back = new Button(this);
        back.setText("Back to Home");
        back.setOnClickListener(v -> {
            removeOverlay();
            // Accessibility global BACK is used instead of launching another
            // copy of Instagram.
            performGlobalAction(GLOBAL_ACTION_BACK);
        });
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(
                -2, dp(52), Gravity.CENTER_HORIZONTAL);
        bp.topMargin = dp(340);
        inner.addView(back, bp);

        // Content-only area; the bottom navigation remains visible.
        FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(-1, -1);
        ip.bottomMargin = dp(78);
        overlay.addView(inner, ip);

        overlay.setVisibility(View.VISIBLE);
    }

    private void showProfileMask() {
        if (wm == null) return;
        if (overlay == null) createOverlay();

        overlay.removeAllViews();
        overlay.setBackgroundColor(Color.TRANSPARENT);

        // Cover only the profile content region below the profile header.
        // The overlay is visually neutral so it feels like an integrated
        // privacy/focus mode rather than a second application.
        View mask = new View(this);
        mask.setBackgroundColor(Color.rgb(7, 7, 10));

        TextView hidden = label("Posts, Reels & Highlights are hidden", 15, Color.rgb(170,170,180));
        hidden.setGravity(Gravity.CENTER);

        FrameLayout region = new FrameLayout(this);
        region.addView(mask, new FrameLayout.LayoutParams(-1, -1));

        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-1, -1);
        hp.topMargin = dp(220);
        hp.bottomMargin = dp(78);
        overlay.addView(region, hp);

        FrameLayout.LayoutParams textP = new FrameLayout.LayoutParams(-1, dp(70));
        textP.topMargin = dp(330);
        textP.leftMargin = dp(20);
        textP.rightMargin = dp(20);
        overlay.addView(hidden, textP);

        overlay.setVisibility(View.VISIBLE);
    }

    private void createOverlay() {
        overlay = new FrameLayout(this);

        // Accessibility overlay: no SYSTEM_ALERT_WINDOW permission is required.
        overlayParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );

        overlayParams.gravity = Gravity.TOP | Gravity.START;
        overlayParams.x = 0;
        overlayParams.y = 0;

        wm.addView(overlay, overlayParams);
    }

    private void removeOverlay() {
        if (overlay != null) {
            overlay.setVisibility(View.GONE);
            overlay.removeAllViews();
        }
    }

    private TextView label(String text, int size, int color) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(12), dp(12), dp(12), dp(12));
        return v;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
