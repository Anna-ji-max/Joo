# FocusGram Integrated — Android prototype

This version is an Android AccessibilityService/overlay architecture intended to work
alongside the official Instagram app.

## What it does

- Instagram remains the app that renders the user's actual account/content.
- FocusGram limits itself to the Instagram package.
- Explore/Reels can be covered with a lightweight focus surface when the accessibility
  tree exposes the corresponding state.
- Other-profile content can be visually masked.
- Instagram's bottom navigation is intentionally left visible.
- The service is dormant when another package is in the foreground.
- No Instagram credentials are collected.
- No private Instagram HTTP endpoints are used.
- No Instagram APK is modified.

## Important Android/platform limitation

AccessibilityService is a powerful Android mechanism. Android's documentation says
accessibility services are intended to assist users with disabilities. It also requires
the user to explicitly enable the service in Android Settings. The service can request
window-content access, draw accessibility overlays, and dispatch gestures when configured
for those capabilities.

This project is therefore a technical prototype. Before distributing it on Google Play,
review Google's current Accessibility API policy and make sure the app qualifies for the
intended use.

Official Android documentation:
https://developer.android.com/reference/android/accessibilityservice/AccessibilityService

## Important Instagram limitation

This app does not receive an official private Instagram feed API. It relies only on
Android accessibility information exposed by the Instagram UI. Instagram can change
its UI, labels, accessibility tree, or package behavior at any time. Therefore a
production-quality version needs device testing against the current Instagram release
and graceful fallbacks.

Do not add private API scraping, certificate pinning bypasses, APK modification, or
credential collection.

## Smoothness strategy

- Service is scoped to `com.instagram.android`.
- No polling loop.
- No screenshot processing.
- Accessibility event timeout is 30 ms.
- UI changes happen only after relevant accessibility events.
- Overlays are reused instead of repeatedly creating windows.
- Bottom navigation is left uncovered.
- The service removes its overlay immediately when leaving a controlled state.

"20 ms" cannot be guaranteed on every Android device because scheduling and Instagram's
own rendering are outside this app's control.

## Build

Open in Android Studio and run `app`.

GitHub Actions workflow:

`.github/workflows/android-build.yml`
